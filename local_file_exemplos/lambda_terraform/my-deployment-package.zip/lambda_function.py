import json
import boto3
import pandas as pd


def get_feature(list_line_dict):
    return [features.get("captureData").get("endpointInput").get("data") for features in list_line_dict]


def get_score(list_line_dict):
    return [score.get("captureData").get("endpointOutput").get("data") for score in list_line_dict]


def create_table(features, score):
    df_features = pd.DataFrame(features)
    df_features = df_features.add_prefix('input_')
    print(df_features)

    df_scores = pd.DataFrame(score)
    df_scores = df_scores.add_prefix('output_')
    print(df_scores)

    df_features_scores = df_features.join(df_scores)
    return df_features_scores


def upload_s3(table):
    client = boto3.client('s3')
    bucket_destiny = 'jeff-s3-bucket-destiny'
    filename = '/tmp/arquivo.csv'
    upload = table.to_csv(filename, index=False)
    print('arquivo convertido!')
    # client.upload_fileobj(filename, bucket_destiny, 'dataframe.csv')
    with open(filename, 'rb') as f:
        client.upload_fileobj(f, bucket_destiny, 'dataframe.csv')
    print('Arquivo csv criado com sucesso!')


def lambda_handler(event, context=None):
    file = event.get('Message')
    bucket_origin = 'jeff-s3-bucket-origin'

    s3 = boto3.resource('s3')
    obj = s3.Object(bucket_origin, file)
    body = obj.get()['Body'].read().decode("utf-8").split("\n")

    list_line_dict = [json.loads(json_str) for json_str in body]

    table = create_table(get_feature(list_line_dict), get_score(list_line_dict))

    upload_s3(table)

    # return {
    #     'statusCode': 200,
    #     'body': json.dumps(body)
    # }
